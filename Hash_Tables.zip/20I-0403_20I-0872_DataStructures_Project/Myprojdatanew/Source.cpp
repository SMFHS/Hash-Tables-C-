#include <iostream>
#include "DHT.h"

int main()
{
	int Identifier_Bits;
	int Number_of_Machines;

	cout << "Enter Identifier Bits" << endl;
	cin >> Identifier_Bits;

Machines:
	cout << "Enter Number of Machines you want to create" << endl;
	cin >> Number_of_Machines;

	if (Number_of_Machines > pow(2, Identifier_Bits))
	{
		goto Machines;
	}




	Ring_DHT obj(Number_of_Machines, Identifier_Bits);
	obj.Make_DHT();
	cout << "\nList Of Machines Created" << endl;
	obj.List_of_Machines();

	int Option;
	int Option2;
	int id;

	cout << "\nMenu" << endl;
Menu:
	do
	{

		cout << "\n1. Add a Machine" << endl;
		cout << "2. Delete a Machine" << endl;
		cout << "3. Enter Data in a Machine" << endl;
		cout << "4. Remove Data from a Machine" << endl;
		cout << "5. Display All Data in a Machine" << endl;
		cout << "6. Display Routing Table of a Machine" << endl;
		cin >> Option;
	} while (!(Option > 0 && Option < 7));

	switch (Option)
	{
	case 1:
		obj.NewMachine();
		cout << "\nNew List: " << endl;
		obj.List_of_Machines();
		break;
	case 2:
		obj.DeleteMachine();
		cout << "\nNew List: " << endl;
		obj.List_of_Machines();
		break;
	case 3:
		cout << "\n";
		obj.DataInsertion();
		break;
	case 4:
		cout << "\n";
		obj.Clear_Machine();
		break;
	case 5:
		cout << "\n";
		obj.Display_Data_of_Machine();
		break;
	case 6:
		cout << "\n";
		obj.List_of_Machines();
		cout << "Enter ID of the Machine to view its Routing Table" << endl;
		cin >> id;
		cout << "Routing Table: " << endl;
		obj.Display_Routing_Table(id);
		break;
	}

Wrong_Input:
	cout << "\n1. Go to Menu" << endl;
	cout << "2.Exit" << endl;
	cin >> Option2;

	if (Option2 == 1)
	{
		goto Menu;
	}
	else if (Option2 == 2)
	{
		exit(0);
	}
	else
	{
		cout << "Wrong input" << endl;
		goto Wrong_Input;
	}









}