#include <iostream>
#include <queue>
#include "AVL_List.h"
using namespace std;

struct AVL_Leaf
{
	AVL_Leaf* Right_Child;
	AVL_Leaf* Left_Child;
	int Key;
	int Height;
	Value_List List;
};

class AVL_Tree
{

public:
	AVL_Leaf* Root;
	AVL_Tree()
	{
		Root = NULL;
	}

	AVL_Leaf* Lrotation(AVL_Leaf* n)
	{
		AVL_Leaf* n2 = n->Right_Child;
		AVL_Leaf* temp = n2->Left_Child;
		n2->Left_Child = n;
		n->Right_Child = temp;
		return n2;
	}

	AVL_Leaf* Rrotation(AVL_Leaf* n)
	{
		AVL_Leaf* n2 = n->Left_Child;
		AVL_Leaf* temp = n2->Right_Child;
		n2->Right_Child = n;
		n->Left_Child = temp;
		return n2;
	}

	AVL_Leaf* rightchildleftchild(AVL_Leaf* n)
	{
		AVL_Leaf* p;
		AVL_Leaf* tp;
		AVL_Leaf* tp2;
		p = n;
		tp = p->Right_Child;
		tp2 = p->Right_Child->Left_Child;

		p->Right_Child = tp2->Left_Child;
		tp->Left_Child = tp2->Right_Child;
		tp2->Left_Child = p;
		tp2->Right_Child = tp;

		return tp2;
	}
	AVL_Leaf* leftchildrightchild(AVL_Leaf* n)
	{
		AVL_Leaf* p;
		AVL_Leaf* tp;
		AVL_Leaf* tp2;
		p = n;
		tp = p->Left_Child;
		tp2 = p->Left_Child->Right_Child;

		p->Left_Child = tp2->Right_Child;
		tp->Right_Child = tp2->Left_Child;
		tp2->Right_Child = p;
		tp2->Left_Child = tp;

		return tp2;
	}

	int height(AVL_Leaf* nodeptr)
	{
		if (nodeptr == NULL)
		{
			return -1;
		}
		else
		{
			int lh = height(nodeptr->Left_Child);
			int rh = height(nodeptr->Right_Child);

			if (lh > rh)
			{
				return lh + 1;
			}
			else
			{
				return rh + 1;
			}
		}
	}

	int height()
	{
		return height(Root);
	}

	AVL_Leaf* New_Leaf(int k, string v)
	{
		AVL_Leaf* New_Leaf = new AVL_Leaf;
		New_Leaf->Key = k;
		New_Leaf->List.Insert(v);
		New_Leaf->Left_Child = NULL;
		New_Leaf->Right_Child = NULL;
		return New_Leaf;
	}

	void Insert(int key, string value)
	{
		Root = Insert(key, value, Root);
	}

	AVL_Leaf* Insert(int key, string value, AVL_Leaf* n)
	{
		if (n == NULL)
		{
			n = New_Leaf(key, value);
			return n;
		}
		else if (key < n->Key)
		{
			n->Left_Child = Insert(key, value, n->Left_Child);

			if (height(n->Left_Child) - height(n->Right_Child) == -2)
			{
				if (key < n->Left_Child->Key)
				{
					n = Lrotation(n);
				}
				else
				{
					n = rightchildleftchild(n);
				}
			}
		}
		else if (key > n->Key)
		{
			n->Right_Child = Insert(key, value, n->Right_Child);

			if (height(n->Right_Child) - height(n->Left_Child) == -2)
			{
				if (key < n->Right_Child->Key)
				{
					n = Rrotation(n);
				}
				else
				{
					n = leftchildrightchild(n);
				}
			}
		}
		n->Height = max(height(n->Left_Child), height(n->Right_Child)) + 1;
		return n;

	}

	int max(int a, int b)
	{
		if (a > b)
		{
			return a;
		}

		else
		{
			return b;
		}

	}
	void Preorder()
	{
		Preorder(Root);
	}
	void Preorder(AVL_Leaf* x)
	{
		if (x != NULL)
		{
			cout <<"\nKey = "<< x->Key <<"   ";
			cout << "Value = ";
			x->List.display();
			cout << "\n";
			Preorder(x->Left_Child);
			Preorder(x->Right_Child);
		}
	}

	void PerformSearch(AVL_Leaf* L, int key)
	{
		if (L == NULL)
		{
			return;
		}
		else if (L->Key == key)
		{
			cout << key << ":\n";
			L->List.display();
			cout << endl;
		}
		else if (key < L->Key)
		{
			PerformSearch(L->Left_Child, key);
		}
		else if (key > L->Key)
		{
			PerformSearch(L->Right_Child, key);
		}
	}

	int Balance_Factor(AVL_Leaf* node)
	{
		if (node == NULL)
		{
			return 0;
		}

		return height(node->Left_Child) - height(node->Right_Child);
	}



	void clear()//to delete all elements that are in queue
	{
		if (Root != NULL)
		{
			queue<AVL_Leaf*> Q;
			AVL_Leaf* Temp = NULL;
			Q.push(Root);

			while (!Q.empty())
			{
				Temp = Q.front();
				Q.pop();

				if (Temp->Left_Child != NULL)
				{
					Q.push(Temp->Left_Child);
				}

				if (Temp->Right_Child != NULL)
				{
					Q.push(Temp->Right_Child);
				}


				Temp->List.Clear();
				delete Temp;
			}

			Root = NULL;
		}
	}
	AVL_Leaf* AVL_Insertion(int Key, Value_List V)
	{
		AVL_Leaf* New_Leaf = new AVL_Leaf;
		New_Leaf->Key = Key;
		New_Leaf->List = V;
		New_Leaf->Left_Child = NULL;
		New_Leaf->Right_Child = NULL;
		return New_Leaf;
	}

	AVL_Leaf* AVL_Insertion(int key, Value_List V, AVL_Leaf* L)
	{
		if (L == NULL)
		{
			L = AVL_Insertion(key, V);
			return L;
		}
		else if (key < L->Key)
		{
			L->Left_Child = AVL_Insertion(key, V, L->Left_Child);
			if (Balance_Factor(L) == 2)
			{
				if (key < L->Left_Child->Key)
					L = Rrotation(L); //RR rotation
				else
					L = leftchildrightchild(L); //LR rotation 
			}
		}
		else if (key > L->Key)
		{
			L->Right_Child = AVL_Insertion(key, V, L->Right_Child);
			if (Balance_Factor(L) == -2)
			{
				if (key > L->Right_Child->Key)
					L = Lrotation(L); //LL rotation
				else
					L = rightchildleftchild(L); //RL rotation
			}
		}

		L->Height = max(height(L->Left_Child), height(L->Right_Child)) + 1;

		return L;
	}

	void SplittingTrees(int key, AVL_Leaf* Currnodeptr, AVL_Tree& T1, AVL_Tree& T2)
	{
		if (Currnodeptr == NULL)
		{
			return;
		}
		if (key <= Currnodeptr->Key)
		{
			T1.Root = T1.AVL_Insertion(Currnodeptr->Key, Currnodeptr->List, T1.Root);
		}
		if (key > Currnodeptr->Key)
		{
			T2.Root = T2.AVL_Insertion(Currnodeptr->Key, Currnodeptr->List, T2.Root);
		}
		SplittingTrees(key, Currnodeptr->Left_Child, T1, T2);
		SplittingTrees(key, Currnodeptr->Right_Child, T1, T2);
	}

	void SplittingTrees(int key, AVL_Tree MainTree, AVL_Tree& T1, AVL_Tree& T2)
	{
		T1.clear();
		T2.clear();
		SplittingTrees(key, MainTree.Root, T1, T2);
	}

	void MergingTree(AVL_Tree& MainTree, AVL_Tree T1, AVL_Tree T2)
	{
		MainTree = T1;

		MainTree.Full_Tree_Insertion(T2.Root, MainTree);
	}

	void Full_Tree_Insertion(AVL_Leaf* L, AVL_Tree& Tree)
	{
		if (L != NULL)
		{
			Tree.Root = Tree.AVL_Insertion(L->Key, L->List, Tree.Root);
			Full_Tree_Insertion(L->Left_Child, Tree);
			Full_Tree_Insertion(L->Right_Child, Tree);
		}
	}

	void PerformSearch(int key)
	{
		PerformSearch(Root, key);
	}
};





