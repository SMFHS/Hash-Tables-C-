#include<iostream>
using namespace std;


struct Node
{
	string Value;
	Node* Next;
};

class Value_List
{
	Node* Head;
public:
	Value_List()
	{
		Head = NULL;
	}

	void Insert(string V)
	{
		Node* Temp = Head;
		Node* New_Node = new Node;
		New_Node->Value = V;
		New_Node->Next = NULL;

		if (Head == NULL)
		{
			Head = New_Node;
		}
		else
		{
			while (Temp->Next != NULL)
			{
				Temp = Temp->Next;
			}
			Temp->Next = New_Node;
		}
	}

	bool Is_Empty()
	{
		if (Head == NULL)
		{
			return true;
		}
		return false;
	}

	void Clear()
	{
		Node* Temp = Head;

		while (Head != NULL)
		{
			Head = Head->Next;
			delete Temp;
			Temp = Head;
		}
	}

	bool Remove(string V)
	{
		if (Is_Empty())
		{
			return false;
		}
		Node* Temp1 = Head;
		Node* Temp2 = NULL;

		while (Temp1 != NULL && Temp1->Value != V)
		{
			Temp2 = Temp1;
			Temp1 = Temp1->Next;
		}

		if (Temp1 == NULL)
		{
			return false;
		}
		else if (Temp1 == Head)
		{
			Head = Temp1->Next;
			delete Temp1;
			return true;
		}
		else
		{
			Temp2->Next = Temp1->Next;
			delete Temp1;
			return true;
		}
	}

	void display()
	{
		Node* Temp = Head;
		while (Temp != NULL)
		{
			cout << Temp->Value << endl;
			Temp = Temp->Next;
		}
	}

	~Value_List()
	{
		//clear();
	}
};

