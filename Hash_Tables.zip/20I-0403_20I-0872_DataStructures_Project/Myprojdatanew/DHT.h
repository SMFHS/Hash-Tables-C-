#include <iostream>
#include <cstdlib>
#include <string>
#include <stdlib.h>
#include <iomanip>
#include "Routing_Table.h"
#include "AVL_Tree.h"
using namespace std;


int Hash_Function(int key, int identifier_space)
{
	int hashed;
	hashed = (key % identifier_space);
	return hashed;
}


struct Machine
{
	int ID;
	int Hashed_ID;
	Routing_Table RT;
	AVL_Tree Tree;
	Machine* Next;
};

class Ring_DHT
{
	Machine* Head;
	int Number_of_Machines;
	int Identifier_Space;
	int Identifier_Bits;

public:
	Ring_DHT()
	{
		Head = NULL;
		Number_of_Machines = 0;
		Identifier_Space = 0;
		Identifier_Bits = 0;
	}
	Ring_DHT(int TotalNoofMachines, int NoofIdentifierbits)
	{
		Number_of_Machines = TotalNoofMachines;
		Identifier_Bits = NoofIdentifierbits;
		Identifier_Space = pow(2, Identifier_Bits);
	}
	Machine* New_Machine(int id, int hashed_id)
	{
		Machine* New_Node = new Machine;
		New_Node->Hashed_ID = hashed_id;
		New_Node->ID = id;
		New_Node->Next = NULL;
		return New_Node;
	}
	void Insert(int id)
	{
		int hashofid = Hash_Function(id, Identifier_Space);
		Insert(id, hashofid);
	}

	void Insert(int id, int hash_id)
	{
		Machine* current = Head;
		Machine* New_Node = New_Machine(id,hash_id);

		if (current == NULL)
		{
			New_Node->Next = New_Node;
			Head = New_Node;
		}
		else if (current->Hashed_ID >= New_Node->Hashed_ID)
		{
			while (current->Next != Head)
			{
				current = current->Next;
			}

			current->Next = New_Node;
			New_Node->Next = Head;
			Head = New_Node;
		}

		else
		{
			while (current->Next != Head && current->Next->Hashed_ID < New_Node->Hashed_ID)
			{
				current = current->Next;
			}

			
			New_Node->Next = current->Next;
			current->Next = New_Node;
		}
	}

	void NewMachine()
	{
		int machineid = 0;
		int hashofid = 0;

		do
		{
			cout << "Please Enter id of New Machine: ";
			cin >> machineid;
			cin.ignore();
			hashofid = Hash_Function(machineid, Identifier_Space);
		} while (machineid < 0 || !Preventing_Repetition(hashofid));

		Insert(machineid, hashofid);
		Machine* currmachine = Search_Machine(hashofid);
		Number_of_Machines++;

		Machine* succmachine = Successor(Hash_Function(hashofid + 1, Identifier_Space));

		AVL_Tree Temp = succmachine->Tree;

		Temp.SplittingTrees(hashofid, Temp, currmachine->Tree, succmachine->Tree);

		Clear_Routing_Table();
		Set_Routing_Table();
	}
	void Make_DHT()
	{

		int Option1;

		do
		{
			cout << "1. Enter ID of Machine Manually" << endl;
			cout << "2. Randomly Assigns IDs of Machine" << endl;
			cin >> Option1;
		} while (!(Option1 > 0 && Option1 < 3));

		int x = Get_Number_of_Machines();
		int y = Identifier_Space / x;
		int Hashed_ID;
		int ID;
		int id = 0;

		switch (Option1)
		{
		case 1:


			for (int i = 0; i < x; i++)
			{
				do
				{
					cout << "Enter ID of Machine" << i + 1 << ": ";
					cin >> ID;
					cin.ignore();
					Hashed_ID = Hash_Function(ID, Identifier_Space);
				} while (Hashed_ID < 0 || !(Preventing_Repetition(Hashed_ID)));

				Insert(ID, Hashed_ID);
			}
			break;
		case 2:



			for (int i = 0; i < x; i++)
			{
				id = rand() % Identifier_Space;
				Insert(id, Hash_Function(id, Identifier_Space));
			}
			break;
		}
		Set_Routing_Table();
	}

	Machine* Successor(int hashofid)
	{
		Machine* Temp = Head->Next;
		Machine* Min_Node = Head;
		Machine* Max_Node = Head;

		do
		{
			if (Min_Node->Hashed_ID > Temp->Hashed_ID)
			{
				Min_Node = Temp;
			}
			if (Max_Node->Hashed_ID < Temp->Hashed_ID)
			{
				Max_Node = Temp;
			}
			Temp = Temp->Next;
		} while (Temp != Head);

		if (hashofid <= Min_Node->Hashed_ID || hashofid > Max_Node->Hashed_ID)
		{
			return Min_Node;
		}

		Temp = Head;
		while (Temp->Hashed_ID < hashofid)
		{
			Temp = Temp->Next;
		}

		return Temp;
	}
	void Display_Data_of_Machine()
	{
		int M;
		cout << "\n";
		List_of_Machines();
		cout << "Enter ID of The Machine you want to view " << endl;
		cin >> M;

		Machine* Temp = Head;
		do
		{
			if (Temp->ID == M)
			{
				break;
			}
			Temp = Temp->Next;
		} while (Temp != Head);

		cout << "Data:";
		Temp->Tree.Preorder();
	}
	void Set_Routing_Table()
	{
		Machine* Temp = Head;
		do
		{
			RT_Node::Referesh_Index();
			for (int i = 1; i <= Identifier_Bits; i++)
			{
				Machine* succ = Successor(Hash_Function(Temp->Hashed_ID + int(pow(2, i - 1)), Identifier_Space));

				Temp->RT.Insert(succ);
			}
			Temp = Temp->Next;
		} while (Temp != Head);
	}

	bool Preventing_Repetition(int hashofid)
	{
		if (Head)
		{
			Machine* Temp = Head;

			do
			{
				if (Temp->Hashed_ID == hashofid)
				{
					return false;
				}
				Temp = Temp->Next;

			} while (Temp->Next != Head);
		}
		return true;
	}

	void Display_Routing_Table(Machine* M)
	{
		RT_Node* rt = M->RT.Get_Head();
		int count = 1;
		while (rt != NULL)
		{
			cout << count++ << setw(20) << "ID: " << rt->machine->ID << endl;
			cout << setw(28) << "Hashed ID: " << rt->machine->Hashed_ID << endl;
			cout << "\n";
			rt = rt->Next;
		}
	}

	Machine* Get_Machine(Machine* M, int index)
	{
		RT_Node* Temp = M->RT.Get_Head();

		while (Temp != NULL && Temp->Index != index)
		{
			Temp = Temp->Next;
		}

		if (Temp == NULL)
		{
			return NULL;
		}
		return Temp->machine;
	}

	void List_of_Machines()
	{
		Machine* Temp = Head;
		int count = 1;
		do
		{
			cout << count++ << ". " << Temp->ID << endl;
			Temp = Temp->Next;
		} while (Temp != Head);
	}

	void Display_Routing_Table(int key)
	{
		Machine* Temp;
		Temp = Search_Machine(Hash_Function(key, Identifier_Space));
		Display_Routing_Table(Temp);
	}

	Machine* Search_Machine(int hash_of_id)
	{
		Machine* Temp = Head;

		do
		{
			if (Temp->Hashed_ID == hash_of_id)
			{
				return Temp;
			}

			Temp = Temp->Next;
		} while (Temp != Head);

		return NULL;
	}



	void Clear_Routing_Table()
	{
		Machine* Temp = Head;
		do
		{
			Temp->RT.Clear();
			Temp = Temp->Next;
		} while (Temp != Head);

		RT_Node::Referesh_Index();
	}

	void Display_DHT()
	{
		if (Head)
		{
			Machine* Temp = Head;
			do
			{
				cout << "\nID: " << Temp->ID << endl;
				cout << "Hashed ID: " << Temp->Hashed_ID << endl;
				cout << "Routing Table:\n";
				Display_Routing_Table(Temp);
				cout << "Data:\n";
				Temp->Tree.Preorder();

				cout << endl << endl;

				Temp = Temp->Next;
			} while (Temp != Head);
		}
	}

	Machine* Find_Machine(int hashofid, Machine* M, bool specialcase)
	{

		if (M->Hashed_ID == hashofid)
		{
			cout << endl;
			return M;
		}

		if (M->Hashed_ID < hashofid)
		{
			Machine* Temp = Get_Machine(M, 0);
			if ((hashofid <= Temp->Hashed_ID) || (specialcase && Temp == Head))
			{
				return Temp;
			}
			else
			{
				int j = 0;
				Machine* Temp2 = Get_Machine(M, j + 1);

				while (j < Identifier_Bits - 1 && hashofid > Temp2->Hashed_ID)
				{
					j++;
					Temp = Temp2;
					if (j + 1 < Identifier_Bits)
						Temp2 = Get_Machine(M, j + 1);

					if (specialcase && Temp2 == Head)
						break;
				}
				return Find_Machine(hashofid, Temp, specialcase);
			}
		}

		if (M->Hashed_ID > hashofid)
		{
			if (Successor(hashofid) == M)
			{
				cout << endl;
				return M;
			}
			else
			{
				int j = 0;
				Machine* Temp3 = Get_Machine(M, j);
				Machine* Temp4 = Get_Machine(M, j + 1);

				while (j < Identifier_Bits - 1 && hashofid < Temp4->Hashed_ID)
				{
					j++;
					Temp3 = Temp4;
					if (j + 1 < Identifier_Bits)
						Temp4 = Get_Machine(M, j + 1);
				}
				return Find_Machine(hashofid, Temp3, specialcase);
			}
		}

	}
	bool checkspecialcase(int hashofid)
	{
		return (Successor(hashofid) == Head);
	}

	void DataInsertion(int hashofid, string data, Machine* machine)
	{
		Machine* M = Find_Machine(hashofid, machine, checkspecialcase(hashofid));
		M->Tree.Insert(hashofid, data);
	}

	void Clear_Machine()
	{
		Machine* Temp = Head;
		int ID;
		List_of_Machines();
		cout << "Enter ID of the Machine you want to delete Data from" << endl;
		cin >> ID;

		do
		{
			if (Temp->ID == ID)
			{
				break;
			}
			Temp = Temp->Next;
		} while (Temp != Head);

		Temp->Tree.clear();

	}

	void DataInsertion()
	{
		int K, ID;
		string data;
		Machine* M;

		do
		{
			cout << "Enter key: ";
			cin >> K;
			cin.ignore();
		} while (K < 0);

		cout << "Enter Data that you want to insert against key " << K << " : ";
		getline(cin, data);

		do
		{
			cout << "\n";
			List_of_Machines();
			cout << "Enter ID of machine you want to Originate Request from : ";
			cin >> ID;
			cin.ignore();
			M = Search_Machine(Hash_Function(ID, Identifier_Space));
		} while (M == NULL);

		DataInsertion(Hash_Function(K, Identifier_Space), data, M);
	}

	void DataSearch(int hashofid, Machine* machine)
	{
		Machine* M = Find_Machine(hashofid, machine, checkspecialcase(hashofid));
		M->Tree.PerformSearch(hashofid);
	}

	void DataSearch()
	{
		int key, ID;
		Machine* M;

		do
		{
			cout << "Enter key: ";
			cin >> key;
			cin.ignore();
		} while (key < 0);

		do
		{
			List_of_Machines();
			cout << "Enter id of machine that you want to use: ";
			cin >> ID;
			cin.ignore();
			M = Search_Machine(Hash_Function(ID, Identifier_Space));
		} while (M == NULL);

		DataSearch(Hash_Function(key, Identifier_Space), M);
	}

	void Remove_Machine(Machine* M)
	{
		if (Head == NULL)
			return;


		else if (Head == Head->Next && Head == M)
		{
			delete Head;
			Head = NULL;
			return;
		}


		else if (Head == M)
		{
			Machine* Temp = Head->Next;
			while (Temp->Next != Head)
				Temp = Temp->Next;
			Temp->Next = Head->Next;
			delete Head;
			Head = Head->Next;
			return;
		}


		Machine* Temp2 = Head->Next;
		while (Temp2->Next != Head && Temp2->Next != M)
		{
			Temp2 = Temp2->Next;
		}


		if (Temp2->Next == M)
		{
			Temp2->Next = Temp2->Next->Next;
			delete M;
			M = NULL;
		}
	}

	void DeleteMachine()
	{
		int machineid;
		Machine* machine;
		do
		{
			List_of_Machines();
			cout << "Enter id of machine that you want to Delete: ";
			cin >> machineid;
			cin.ignore();
			machine = Search_Machine(Hash_Function(machineid, Identifier_Space));
		} while (machine == NULL);

		Machine* succmachine = Successor(Hash_Function(machine->Hashed_ID + 1, Identifier_Space));

		AVL_Tree Temp = succmachine->Tree;

		succmachine->Tree.clear();

		succmachine->Tree.MergingTree(succmachine->Tree, machine->Tree, Temp);

		machine->Tree.clear();
		Remove_Machine(machine);
		Number_of_Machines--;

		Clear_Routing_Table();
		Set_Routing_Table();
	}

	int Get_Identifier_Space()
	{
		return Identifier_Space;
	}

	int Get_Identifier_Bits()
	{
		return Identifier_Bits;
	}

	int Get_Number_of_Machines()
	{
		return Number_of_Machines;
	}

};