#include <iostream>
using namespace std;

struct Machine;

struct RT_Node
{
	int Index;
	static int x;
	RT_Node* Next;
	RT_Node* Previous;
	Machine* machine;

	RT_Node()
	{
		Index = -1;
		Next = NULL;
		Previous = NULL;
		machine = NULL;
	}
	RT_Node(Machine* M)
	{
		Index = x++;
		machine = M;
		Next = NULL;
		Previous = NULL;
	}
	static void Referesh_Index()
	{
		x = 0;
	}
};

int RT_Node::x = 0;

class Routing_Table
{
	RT_Node* Head;
	RT_Node* Tail;
public:
	Routing_Table()
	{
		Head = NULL;
		Tail = NULL;
	}

	void Insert(Machine* M)
	{
		if (Is_Empty() == true)
		{
			Head = new RT_Node(M);
			Tail = Head;
		}
		else
		{
			Tail->Next = new RT_Node(M);
			Tail->Next->Previous = Tail;
			Tail = Tail->Next;
		}
	}



	bool Is_Empty()
	{
		if (Head == NULL && Tail == NULL)
		{
			return true;
		}
	}

	void Clear()
	{
		RT_Node* Temp = Head;
		while (Head != NULL)
		{
			Head = Head->Next;
			delete Temp;
			Temp = Head;
		}
		Tail = Head;
	}

	RT_Node* Get_Head()
	{
		return Head;
	}

	RT_Node* Get_Tail()
	{
		return Tail;
	}

};
